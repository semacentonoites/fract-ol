/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   2.c                                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: erferrei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/11 05:21:44 by erferrei          #+#    #+#             */
/*   Updated: 2024/04/11 05:21:53 by erferrei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minilibx-linux/mlx.h"
#include <X11/Xlib.h>
#include <stdio.h>

int main() {
    Display *display;
    Window window;
    XEvent event;
    Atom wmDeleteMessage;

    display = XOpenDisplay(NULL);
    if (display == NULL) {
        fprintf(stderr, "Error opening display\n");
        return 1;
    }

    int screen = DefaultScreen(display);
    window = XCreateSimpleWindow(display, RootWindow(display, screen), 100, 100, 400, 300, 1,
                                 BlackPixel(display, screen), WhitePixel(display, screen));

    XSelectInput(display, window, ExposureMask | StructureNotifyMask);
    XMapWindow(display, window);

    wmDeleteMessage = XInternAtom(display, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(display, window, &wmDeleteMessage, 1);

    while (1) {
        XNextEvent(display, &event);
        if (event.type == ClientMessage && event.xclient.message_type == XInternAtom(display, "WM_PROTOCOLS", True)
            && (Atom)event.xclient.data.l[0] == wmDeleteMessage) {
            // Handle close event
            printf("Close button clicked\n");
            break;
        }
    }

    XDestroyWindow(display, window);
    XCloseDisplay(display);
    return 0;
}
